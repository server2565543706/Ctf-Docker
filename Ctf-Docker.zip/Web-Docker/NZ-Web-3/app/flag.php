<?php
$flag = "flag{123}";